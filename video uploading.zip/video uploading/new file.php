<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "video file";
$con = mysqli_connect($servername, $username, $password, $dbname);
if(isset($_POST['upload'])) {
	$extention=array('mp4','mp3');
	foreach ($_FILES['video']['tmp_name'] as $key => $value) {
		$filename=$_FILES['video']['name'][$key];
		$filename_tmp=$_FILES['video']['tmp_name'][$key];
		echo "<br>";
		$ext=pathinfo($filename,PATHINFO_EXTENSION);
		if(in_array($ext,$extention))
		{
			if(!file_exists('videos/'.$filename))
			{
				move_uploaded_file($filename_tmp, 'videos/'.$filename);
				$finalvideo=$filename;
			}else{
				$filename=str_replace('-','-',basename($filename,$ext));
				$newfilename=$filename.time().".".$ext;
				move_uploaded_file($filename_tmp, 'videos/'.$newfilename);
				$finalvideo=$newfilename;
			}
			$creattime=date('Y-m-d h:i:s');
			$insertqry="INSERT INTO admin('video1','video2')VALUES('$finalvideo','$creattime')";
			mysql_query($con,$insertqry);
			header('Location:admin panel.php');
			}
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	 <title>video</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
</head>
<body>
	<div class="container">
		<div class="col-md-12">
			<div class="row">
			<div class="col-md-6">
				<h3 class="text-center">upload</h3>
				<form class="mt-5" method="post" enctype="multipart/form-data">
					<input type="file" name="video[]" class="form-control" multiple>
					<input type="submit" name="upload" value="UPLOAD" class="btn-btn-success">
					</form>
			</div> 
			
			</div>
			
		</div>
		
	</div>
</body>
</html>
